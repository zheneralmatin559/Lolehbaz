import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class TrackProvider extends ChangeNotifier {
  List<LatLng> path = [];
  bool walking = false;
  int walkSeconds = 0;
  int restSeconds = 0;

  void addPoint(LatLng p) {
    path.add(p);
    notifyListeners();
  }

  void startWalk() {
    walking = true;
    notifyListeners();
  }

  void stopWalk() {
    walking = false;
    notifyListeners();
  }

  void tick() {
    if (walking) walkSeconds++;
    else restSeconds++;
    notifyListeners();
  }
}
