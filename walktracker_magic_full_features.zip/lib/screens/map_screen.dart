import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:provider/provider.dart';
import '../providers/track_provider.dart';

class MapScreen extends StatefulWidget {
  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  GoogleMapController? mapCtrl;
  Location loc = Location();
  StreamSubscription? sub;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(seconds:1), (_) {
      context.read<TrackProvider>().tick();
    });
    _startLocation();
  }

  void _startLocation() async {
    bool enabled = await loc.serviceEnabled() || await loc.requestService();
    PermissionStatus perm = await loc.hasPermission();
    if (perm == PermissionStatus.denied) perm = await loc.requestPermission();
    sub = loc.onLocationChanged.listen((d) {
      final p = LatLng(d.latitude!, d.longitude!);
      context.read<TrackProvider>().addPoint(p);
      mapCtrl?.animateCamera(CameraUpdate.newLatLng(p));
    });
  }

  @override
  void dispose() {
    sub?.cancel();
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<TrackProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text("Walk Tracker")),
      body: Stack(
        children: [
          GoogleMap(
            onMapCreated: (c) => mapCtrl = c,
            initialCameraPosition: const CameraPosition(
              target: LatLng(35.6892, 51.3890),
              zoom: 15,
            ),
            polylines: {
              Polyline(
                polylineId: const PolylineId("walk"),
                points: prov.path,
                color: Colors.blue,
                width: 6,
              )
            },
          ),
          Positioned(
            top: 20,
            left: 10,
            child: Container(
              padding: const EdgeInsets.all(8),
              color: Colors.white.withOpacity(0.8),
              child: Column(
                children: [
                  Text("Walking: ${prov.walkSeconds}s"),
                  Text("Resting: ${prov.restSeconds}s"),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          prov.walking ? prov.stopWalk() : prov.startWalk();
        },
        child: Icon(prov.walking ? Icons.pause : Icons.play_arrow),
      ),
    );
  }
}
