import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:walktracker/providers/track_provider.dart';
import 'package:walktracker/screens/map_screen.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => TrackProvider(),
      child: const WalkTrackerApp(),
    ),
  );
}

class WalkTrackerApp extends StatelessWidget {
  const WalkTrackerApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MapScreen(),
    );
  }
}
